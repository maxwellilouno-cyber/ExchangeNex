# OmniRate FX - Professional Currency Converter & Historical Trends

A high-performance real-time currency exchange calculator, historical trend visualization charts, multi-currency watchlist, and foreign transfer fee analyzer.

## Features
- Real-time exchange rates for 50+ global currencies
- Dual fallback to European Central Bank & Interbank spot rates
- Interactive historical chart with 7D, 1M, 3M, 6M, 1Y, and 5Y timeframes, moving averages, and CSV export
- Multi-currency portfolio watchlist with 7-day sparklines
- Foreign exchange fee and spread analyzer
- Specific historical calendar date rate lookup
- Target rate alert tracker with local persistence
- Installable Progressive Web App (PWA) with offline capabilities

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run development server:
```bash
npm run dev
```

3. Build production bundle:
```bash
npm run build
```

## Building an Android APK

To build a native Android APK from this project:
1. Install Capacitor:
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "OmniRate FX" "com.omnirate.app" --web-dir dist
npm run build
npx cap add android
npx cap copy
npx cap open android
```
2. In Android Studio, go to **Build > Build Bundle(s) / APK(s) > Build APK(s)** to generate your installable `.apk` file!
